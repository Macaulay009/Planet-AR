using UnityEngine;
using UnityEngine.SceneManagement;


public class SceneControler : MonoBehaviour
{
    public void SwitchScene(string sceneName)
    {
        SceneManager.LoadScene(sceneName);
    }// Start is called once before the first execution of Update after the MonoBehaviour is created  
}
